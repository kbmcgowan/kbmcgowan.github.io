Sinewave speech sentences downloaded from Chris Darwin's web site:

     http://www.lifesci.sussex.ac.uk/home/Chris_Darwin/SWS/

Site includes non-sinewave versions and a Praat script to generate SWS.

